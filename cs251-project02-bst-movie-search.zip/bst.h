/*bsh.h*/

//
// Binary search tree
//

#pragma once

#include <iostream>
#include <algorithm>  // std::max

#include <cmath>

using namespace std;

//My Addition: Modified template code as per instructions in Project 02
template<typename TKey, typename TValue>
class binarysearchtree
{
private:
  
  struct NODE
  {
    TKey   Key;
	TValue Value;
    NODE*  Left;
    NODE*  Right;
  };

  NODE* Root;  // pointer to root node of tree (nullptr if empty)
  int   Size = 0;  // # of nodes in the tree (0 if empty)

  // _inorder does the actual inorder traversal and output 
  // to console.  Each key is output to the console followed
  // by " ", including the last key.
  
  // CAUTION: This may need to be updated to display ALL the values in the Tree Nodes
  
  void _inorder(NODE* cur)
  {
     if (cur == nullptr)
       return;
     else
     {
        _inorder(cur->Left);
        cout << cur->Value.ID << " ";
		cout << cur->Value.MovieName << " ";
		cout << cur->Value.PubYear << " ";
		cout << cur->Value.Num5Stars << " ";
		cout << cur->Value.Num4Stars << " ";
		cout << cur->Value.Num3Stars << " ";
		cout << cur->Value.Num2Stars << " ";
		cout << cur->Value.Num1Stars << " "; 
		cout << cur->Value.AVG << endl;
        _inorder(cur->Right);
     }
  }
  
  int _height(NODE* cur) 
  {
     
     int leftHeight;
     int rightHeight;
     
     if (cur == nullptr)
       return -1;
     else
     {
        leftHeight = _height(cur->Left);
        rightHeight = _height(cur->Right);
        return 1 + max(leftHeight, rightHeight);
     }
  }


  // My Addition:
  // I added a "private" insert function because I was not able to access the public insert function
  // from my private _copyconstructor function
  void _insert(TKey key, TValue value)
  {
    NODE* prev = nullptr;
    NODE* cur = Root;
	
    // 1. Search to see if tree already contains key:
    while (cur != nullptr)
    {
      if (key == cur->Key){  // already in tree
        return;
      }
	  
      if (key < cur->Key)  // search left:
      {
        prev = cur;
        cur = cur->Left;
      }
      else
      {
        prev = cur;
        cur = cur->Right;
      }
    }

    // 2. if we get here, key is not in tree, so allocate
    // a new node to facilitate insert function.
    
    // Step One: Allocate a New Node
    NODE* newNode = new struct NODE;
    
    // Step Two: Store Key
    newNode->Key = key;
    
    // Step Three: Initialize Pointer Fields
    newNode->Left = nullptr;
    newNode->Right = nullptr;
   
    // My Addition for Project 02: 
    // Step Four: Store Struct of Values
    newNode->Value = value;
	
    // 3. link in the new node:
    // NOTE: We know cur is null, and prev denotes node where
    // we fell out of the tree.  if prev is null, then
    // the tree is empty and the Root pointer needs 
    // to be updated.

	// Step One: Check to See if Prev is Null and Update Root if Needed
    if (prev == nullptr) 
    {
      Root = newNode;
      Size = Size + 1;
      return; 
    }    
    
    // Step Two: Link Prev Node to newNode
    if (key < prev->Key) 
    {
      prev->Left = newNode; 
    } else {
      prev->Right = newNode;
    }

	// 4. update size and we're done:
    Size = Size + 1;
  }


  // My Addition:
  // Private Implementation of Copy Constructor
  void _copyconstructor(NODE* original)
  {  
	 TKey A;
	 TValue B; 
	 
	 if (original == nullptr){
	   return;
     } 
	 else
     {
	   A = original->Key;
	   B = original->Value;
	   _insert(A, B);
       _copyconstructor(original->Left);
       _copyconstructor(original->Right);
     }
	
	 return;
  }


public:
  // default constructor:
  // Creates an empty tree.
  binarysearchtree()
  {
    Root = nullptr;
    Size = 0;
  }

  // size:
  // Returns the # of nodes in the tree, 0 if empty.
  int size()
  {
    return Size;
  }

  // height:
  // Computes and returns height of tree; height of an empty tree is
  // defined as -1.
  int height()
  {
    // Need to Call a Private _height() function
    int height;
    
    height = _height(Root);
   
    return height;
  }
 
  // search:
  // Searches the tree for the given key, returning true if found
  // and false if not.
  TValue* search(TKey key)
  {
    NODE* cur = Root;

    while (cur != nullptr)
    {
      if (key == cur->Key){  // already in tree
		return &(cur->Value); // returns a pointer to the value stored in the node
	   } 
	   else if (key < cur->Key)  // search left:
      {
        cur = cur->Left;
      }
      else
      {
        cur = cur->Right;
      }
    }  
  
    // If we get here, then that means the searched for value does not exist.
    return nullptr;
  }

  // insert:
  // Inserts the given key into the tree; if the key has already been insert then
  // the function returns without changing the tree.
  void insert(TKey key, TValue value)
  {
    NODE* prev = nullptr;
    NODE* cur = Root;

    // 1. Search to see if tree already contains key:
    while (cur != nullptr)
    {
      if (key == cur->Key)  // already in tree
        return;

      if (key < cur->Key)  // search left:
      {
        prev = cur;
        cur = cur->Left;
      }
      else
      {
        prev = cur;
        cur = cur->Right;
      }
    }

    // 2. if we get here, key is not in tree, so allocate a new node to insert.

	// Step One: Allocate a New Node
    NODE* newNode = new struct NODE;
    
    // Step Two: Store Key
    newNode->Key = key;
    
    // Step Three: Initialize Pointer Fields
    newNode->Left = nullptr;
    newNode->Right = nullptr;
   
    // My Addition for Project 02: 
    // Step Four: Store Struct of Values
    newNode->Value = value;
	
    // 3. link in the new node:
    // NOTE: cur is null, and prev denotes node where
    // we fell out of the tree.  if prev is null, then
    // the tree is empty and the Root pointer needs 
    // to be updated.

    // Step One: Check to See if Prev is Null and Update Root if Needed
    
    if (prev == nullptr) 
    {
      Root = newNode;
      Size = Size + 1;
      return; 
    }
        
    // Step Two: Link Prev Node to newNode
    if (key < prev->Key) 
    {
      prev->Left = newNode; 
    } else {
      prev->Right = newNode;
    }

	// 4. update size and we're done:
    Size = Size + 1;
  }

  // inorder:
  // Performs an inorder traversal of the tree, outputting the keys to the console.
  void inorder()
  {
     cout << "Inorder: ";
     
     _inorder(Root);
     
     cout << endl;
  }

  // My Addition for Project 02:
  // copy constructor
  binarysearchtree(binarysearchtree& other)
  {
	  Root = nullptr;  // Initializes a New Root for the Destination BST
	  Size = 0;        // Initializes a New Size for the Destination BST
	  NODE* originalRoot = new struct NODE;
	  originalRoot = other.Root;
	  _copyconstructor(originalRoot);
	  return;
  }

};
