// John D. McDonald
// U. of Illinois, Chicago
// CS 251: Fall 2019
//
// Project #02: inputs movies and reviews, allowing the user to search
// by movie ID, movie Name, or review ID.  Uses binary search trees for 
// fast search; no other data structures are allowed.
//

#include <iostream>
#include <fstream>
#include <string>
#include "bst.h"

using namespace std;

// My Addition: This is a new struct to hold the data within a NODE
struct MovieData
{
	int ID;
	string MovieName;
	int PubYear;
	int Num5Stars;
	int Num4Stars;
	int Num3Stars;
	int Num2Stars;
	int Num1Stars;
	double AVG;
};  

//My Addition:
//Declare Both BST Trees UpFront to Avoid Scoping Issues

binarysearchtree<int, MovieData> IDTREE;
binarysearchtree<string, MovieData> NAMETREE;

//
// trim
//
// trims whitespace from beginning and end of string.
//
// Ref: https://stackoverflow.com/questions/25829143/trim-whitespace-from-a-string
// Modified: to handle empty strings, and strings of all blanks.
//
string trim(const string& str)
{
  size_t first = str.find_first_not_of(" \t\n\r");
  size_t last = str.find_last_not_of(" \t\n\r");

  if (first == string::npos && last == string::npos)  // empty, or all blanks:
    return "";
  else if (first == string::npos)  // no blanks at the start:
    first = 0;                     // 0-based
  else if (last == string::npos)   // no blanks trailing at end:
    last = str.length() - 1;       // 0-based

  return str.substr(first, (last - first + 1));
}

// InputMovies
//
// Inputs the data from the "movies" file, which contains N>0 lines, where
// each line contains:
//     id pubYear name
//
void InputMovies(string moviesFilename)
{
  ifstream moviesFile(moviesFilename);
  int      id, pubYear;
  string   name;

  if (!moviesFile.good())
  {
    cout << "**Error: unable to open movies file '" << moviesFilename << "', exiting" << endl;
    return;
  }
	
  moviesFile >> id;  // get first ID, or set EOF flag if file empty:
	
  while (!moviesFile.eof())
  {
    // we have more data, so input publication year and movie name:
    moviesFile >> pubYear;
    getline(moviesFile, name);  // movie name fills rest of input line:

    // trim potential whitespace from both ends of movie name:
    name = trim(name);  

	//My Additions:
	//First: We need to create an object of the MovieData struct type.
	//Second: We need to store the pubYear in the object.
	//Third:  We need to insert a Node into the BST called IDTREE, where the key is the movieID.
	//Fourth: We need to insert a Node into the BST called NAMETREE, where the key is the moviename.
	
	// Step One: Create an Object of the MovieData struct type.  
	MovieData TempData;
    
	// Step Two: Store the pubYear in the TempData struct.
	TempData.ID = id;
	TempData.MovieName = name;
	TempData.PubYear = pubYear;
	TempData.Num5Stars = 0;
	TempData.Num4Stars = 0;
	TempData.Num3Stars = 0;
	TempData.Num2Stars = 0;
	TempData.Num1Stars = 0;
	TempData.AVG = 0;
	
    // Step Three: Insert Node Into IDTREE
	IDTREE.insert (id, TempData);
	
	// Step Four: Insert Node into NAMETREE
	NAMETREE.insert(name, TempData);
	  
    moviesFile >> id;  // get next ID, or set EOF flag if no more data:
  }
}

int InputData (string reviewsFilename) {
	
	ifstream reviewsFile(reviewsFilename);
	int numReviews;  // Stores the Aggregate Number of Reviews in the reviews1.txt file
	int integerReviewId;  // Temporarily Stores the Review ID which is not Stored in Each Tree Node
	int movieId;  // Stores the MovieID read in from reviews1.txt file    
	int stars;  // Stores the Stars Associated with that Review
	MovieData* returnedValue = new struct MovieData; // Stores the Memory Address of Whatever Value is Returned from .search(TKey key)
    int Sum; // Stores the Number of Reviews Associated with a Specific Movie ID and NOT the total number of reviews
	string correlativeName; // Stores the name of the movie associated with the ID
	
	if (!reviewsFile.good())
	{
    cout << "**Error: unable to open movies file '" << reviewsFilename << "', exiting" << endl;
    return 0;
	}
	
    reviewsFile >> integerReviewId;  // get first ID, or set EOF flag if file empty:
	
	numReviews = 0; // Initialize the Number of Reviews to Zero
	
    while (!reviewsFile.eof()) {
  
    // We have more data, so input publication year and movie name:
    reviewsFile >> movieId;
    reviewsFile >> stars;
		
	// You Now Have Read in An Entire Line from reviews1.txt
	
	// UPDATE THE IDTREE
	// First: Find the MovieData Struct Associated with this movieId and store it in returnedValue
	returnedValue = IDTREE.search(movieId); 
		
	// Second: Update the NumStars in the MovieData Struct Associated with this Node
    if (stars == 5) {
		returnedValue->Num5Stars = returnedValue->Num5Stars + 1;
	} else if (stars == 4) {
		returnedValue->Num4Stars = returnedValue->Num4Stars + 1;
	} else if (stars == 3) {
		returnedValue->Num3Stars = returnedValue->Num3Stars + 1;
	} else if (stars == 2) {
		returnedValue->Num2Stars = returnedValue->Num2Stars + 1;
	} else if (stars == 1) {
		returnedValue->Num1Stars = returnedValue->Num1Stars + 1;
	}

	// Third: Update the AVG Member of the MovieData Struct Associated with this Node
	Sum = returnedValue->Num5Stars + returnedValue->Num4Stars + returnedValue->Num3Stars + returnedValue->Num2Stars + returnedValue->Num1Stars;	
	returnedValue->AVG = double(((5*(returnedValue->Num5Stars)) + (4*(returnedValue->Num4Stars)) + (3*(returnedValue->Num3Stars)) + (2*(returnedValue->Num2Stars)) + (returnedValue->Num1Stars))/(double(Sum)));	
		
	// UPDATE THE NAMETREE
	// First: Find the "name" Associated with the IDTREE
	correlativeName = returnedValue->MovieName;
		
	// Second: Search for the Relevant Node and Store the MovieData Struct in returnedValue
	returnedValue = NAMETREE.search(correlativeName);
		
	// Third: Update the NumStars in the MovieData Struct Associated with this Node
    if (stars == 5) {
		returnedValue->Num5Stars = returnedValue->Num5Stars + 1;
	} else if (stars == 4) {
		returnedValue->Num4Stars = returnedValue->Num4Stars + 1;
	} else if (stars == 3) {
		returnedValue->Num3Stars = returnedValue->Num3Stars + 1;
	} else if (stars == 2) {
		returnedValue->Num2Stars = returnedValue->Num2Stars + 1;
	} else if (stars == 1) {
		returnedValue->Num1Stars = returnedValue->Num1Stars + 1;
	}

	// Fourth: Update the AVG Member of the MovieData Struct Associated with this Node
	Sum = returnedValue->Num5Stars + returnedValue->Num4Stars + returnedValue->Num3Stars + returnedValue->Num2Stars + returnedValue->Num1Stars;	
	returnedValue->AVG = double(((5*(returnedValue->Num5Stars)) + (4*(returnedValue->Num4Stars)) + (3*(returnedValue->Num3Stars)) + (2*(returnedValue->Num2Stars)) + (returnedValue->Num1Stars))/(double(Sum)));	
		
	reviewsFile >> integerReviewId;
	 
	numReviews = numReviews + 1;  // Increment numReviews by 1 to reflect the fact that 1 review has been processed
		
	}
	return numReviews;
}


//
// main
//
int main()
{
  unsigned int i;  // General Purpose Iterator
  int numReviews;  // Stores the Return Value from InputData Function
  string input; // Used to Get the Movie Name
  int inputInt; // Used Only When Needed to Convert input from string to int 
  string moviesFilename; // = "movies1.txt";
  string reviewsFilename; // = "reviews1.txt";
  MovieData* returnedValue = new struct MovieData; // Stores the TValue Returned from a Search
  bool alpha; // Create a Boolean to Determine Whether User Input MovieName or MovieID 	
	

	  
  cout << "movies file?> ";
  cin >> moviesFilename;

  cout << "reviews file?> ";
  cin >> reviewsFilename;
	
  string junk;
  getline(cin, junk);  // discard EOL following last input:
	
  //CAUTION: This Only Creates the Trees
  //It does not fill in the Data	
  InputMovies(moviesFilename);	
  
  //MyAddition:
  //This is the function that fills in the data and returns
  //the number of reviews
  numReviews = InputData(reviewsFilename); 
	
	//Debugging Statements Only
//  cout << "This is the IDTREE in order: "; 
  
//  IDTREE.inorder(); 
  
//  cout << endl;
  
//  cout << "This is the NAMETREE in order: "; 
	
//  NAMETREE.inorder(); 
	
  cout << "Num movies: " << NAMETREE.size() << endl;
  cout << "Num reviews: " << numReviews << endl;
  
  cout << endl;

  cout << "Tree by movie id: " << "size=" << IDTREE.size() <<", height=" << IDTREE.height() << endl;
  cout << "Tree by movie name: " << "size=" << NAMETREE.size() <<", height=" << NAMETREE.height() << endl;
	
  cout << endl;

  while (input != "#") 
  {
  // Get User Input
  // CAUTION: This can be a movie id or filename of # 	
  cout << "Enter a movie id or name (or # to quit)> ";
  getline(cin, input); // read entire input line
  
  if (input == "#") 
  {
	break;  
  }
	  
  // Check to See if User Entered MovieName	
	for (i = 0; i<input.length(); ++i)
	{
		if (isalpha(input[i])) {
			alpha = true;
			break;
		} else {
			alpha = false;
		}
	}
  
  //If User Entered Movie Name Search Name Tree
  //If User Entered Movie ID Search ID Tree
	if (alpha) { 
		returnedValue = NAMETREE.search(input);
	} else {
		inputInt = stoi(input);
		returnedValue = IDTREE.search(inputInt);
	}  
  
  // The TValue Associated with the Appropriate Node is Established
  // Check Whether returnedValue is a nullptr
  // If it is, then tell user node not found
  // If it is not, then print the Members of the TValue of the Relevant Node
  
  if (returnedValue == nullptr) 
  {
	 cout << "not found..." << endl << endl;  
  } else {
	 cout << "Movie ID: " << returnedValue->ID << endl;
	 cout << "Movie Name: " << returnedValue->MovieName << endl;
	 cout << "Avg rating: " << returnedValue->AVG << endl;
	 cout << "5 stars: " << returnedValue->Num5Stars << endl;
	 cout << "4 stars: " << returnedValue->Num4Stars << endl;
	 cout << "3 stars: " << returnedValue->Num3Stars << endl;
	 cout << "2 stars: " << returnedValue->Num2Stars << endl;
	 cout << "1 star: " << returnedValue->Num1Stars << endl;
	 cout << endl;
	 // Continue While Loop
	}
  }
  return 0;
}
